import * as React from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import Button from "@mui/material/Button";
import AddSegment from "./AddSegemnt";

export default function SideDrawer() {
  const [showSideBar, setShowSideBar] = React.useState(false);
 

  return (
    <div>
      {
        <React.Fragment key={"right"}>
          <Button onClick={() => setShowSideBar(true)}>Save Segment</Button>
          <Drawer
            anchor={"right"}
            open={showSideBar}
            onClose={() => setShowSideBar(false)}
            onClick={(e) => e.stopPropagation()} 
          >
            <Box
              sx={{ width: 400, height: "100%" }}
              role="presentation"        
              onKeyDown={() => setShowSideBar(false)}
            >
        
              <AddSegment setShowSideBar={setShowSideBar} />
            </Box>
          </Drawer>
        </React.Fragment>
      }
    </div>
  );
}
