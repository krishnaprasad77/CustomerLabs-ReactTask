import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import RemoveIcon from "@mui/icons-material/Remove";
import { useState } from "react";
import { fetchApi } from "../service/fetchAPI";

function Task({ arr, buttons }) {
  const btn = buttons.map((button) => button.value);
  const list = arr.filter((schema) => !btn.includes(schema.value));

  return (
    <>
      {list.map((schema) => (
        <option key={schema.value} value={schema.value}>
          {schema.label}
        </option>
      ))}
    </>
  );
}

const AddSegment = ({ setShowSideBar }) => {
  const [segmentName, setSegmentName] = useState("");

  const [schemas, setSchemas] = useState([
    { id: 1, label: "First Name", value: "first_name" },
    { id: 2, label: "Last Name", value: "last_name" },
    { id: 3, label: "Gender", value: "gender" },
    { id: 4, label: "Age", value: "age" },
    { id: 5, label: "Account Name", value: "accountName" },
    { id: 6, label: "City", value: "city" },
    { id: 7, label: "State", value: "state" },
  ]);
  const [selectedInputData, setSelectedInputData] = useState([
    { id: 1, options: [...schemas] },
  ]);

  const handleSchemaChange = (e, selectedSchema) => {
    selectedSchema["value"] = e.target.value;
    selectedSchema["label"] = e.target.name;
    setSelectedInputData([...selectedInputData]);
  };

  const handleAddSchema = () => {
    const newSelectedInputData = [...selectedInputData];
    const usedSchemas = newSelectedInputData.map((dropDown) => dropDown.value);
    const availableSchemas = [...schemas].filter(
      (option) => !usedSchemas.includes(option.value)
    );
    newSelectedInputData.push({
      id: selectedInputData.length + 1,
      options: availableSchemas,
    });
    setSelectedInputData([...newSelectedInputData]);
  };

  const handleCancelSchema = (id) => {
    const newremovedInputData =  selectedInputData.filter(inputData => inputData.id !== id);

    const usedSchemas = newremovedInputData.map((dropDown) => dropDown.value);
    const availableSchemas = [...schemas].filter(
      (option) => !usedSchemas.includes(option.value)
    );
    newremovedInputData[newremovedInputData.length -1].options = availableSchemas
    setSelectedInputData([...newremovedInputData]);  
  };

  const finalSubmit = async () => {
    if (segmentName.trim() === "") {
      alert("Please enter the segment name.");
      return;
    }

    if(selectedInputData.every(selectedData => !selectedData.value)) {
      alert("Please enter the valid schema.");
      return;
    }

    const schemaData = selectedInputData.map((selectedSchema) => ({
      [selectedSchema.value] : schemas.find((schema) => schema.value === selectedSchema.value).label
    }));

    const data = {
      segment_name: segmentName,
      schema: schemaData,
    };
    fetchApi(data).then(() => {
      resetFields();
    });
  };

  const resetFields = () => {
    setSegmentName("");
    setSelectedInputData([{ id: 1, options: [...schemas] }])    
  };

  const validAddSchema = () => {
    if (selectedInputData.length === 7) return true;
    else {
      return selectedInputData.every((dropDown) => !dropDown.value);
    }
  };

  return (
    <>
      <div
        onClick={e => e.stopPropagation()}
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          height: "100%",
        }}
      >
        <div>
          <div>
            <h3
              style={{
                margin: 0,
                color: "white",
                backgroundColor: "teal",
                padding: " 15px 10px",
                display: "flex",
                alignItems: "center",
              }}
            >
              <ChevronLeftIcon
                fontSize="large"
                onClick={() => setShowSideBar(false)}
              />
              <span>Saving Segment</span>
            </h3>
          </div>
          <div style={{ padding: "10px" }} className="segment">
            <h4>Enter The Name Of The Segment</h4>
            <input
              style={{
                padding: "10px",
                width: "350px",
                outline: 0,
                borderRadius: "5px",
              }}
              type="text"
              placeholder="Name of the segment"
              value={segmentName}
              onKeyDown={e => e.stopPropagation()}
              onChange={(e) => {
                setSegmentName(e.target.value);
            }}
            />
          </div>
          <div
            style={{ padding: "10px", fontSize: "15px", lineHeight: "25px" }}
          >
            <p className="instruction">
              To save your segment, you need to add the schemas to build the
              query
            </p>
          </div>
          <div style={{ padding: "10px" }}>
            {selectedInputData.map((button,index) => (
              <div
                key={button.id}
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  margin: "10px 0",
                }}
              >
                <select
                  style={{
                    padding: "10px",
                    width: "320px",
                    outline: 0,
                  }}
                  name={button.label}
                  disabled={selectedInputData.length - 1 !== index}
                  onChange={(e) => {
                    handleSchemaChange(e, button);
                  }}
                >
                    <option value={""}>Add Schema to segment</option>
                  {button.options.map((schema) => (
                    <option key={schema.id} value={schema.value}>{schema.label}</option>
                  ))}
                </select>
                {index !== 0 &&<button
                  style={{
                    backgroundColor: "rgba(221, 252, 252, 0.532)",
                    border: 0,
                    borderRadius: "5px",
                  }}
                  onClick={() => handleCancelSchema(button.id)}
                >
                  <RemoveIcon fontSize="large" style={{cursor : 'pointer'}} />
                </button>
                }
              </div>
            ))
            }
            <button
              style={{
                border: "0",
                outline: 0,
                background: "white",
                cursor: "pointer",
                color: validAddSchema() ? "gray" : "teal",
                "&:hover": {
                  cursor: "pointer",
                  borderBottom: validAddSchema()
                    ? "2px solid gray !important"
                    : "2px solid teal !important",
                },
              }}
              disabled={validAddSchema()}
              className="addSchema"
              onClick={handleAddSchema}
            >
              + Add new schema
            </button>
          </div>
        </div>
        <div
          style={{
            backgroundColor: "  rgba(204, 198, 198, 0.605)",
            padding: "20px",
            display: "flex",
            alignItems: "center",
            width: "360px",
          }}
        >
          <button
            style={{
              backgroundColor: "teal",
              color: "white",
              padding: "10px 20px",
              borderRadius: "6px",
              cursor : 'pointer',
              outline: 0,
              border: 0,
            }}
            onClick={finalSubmit}
          >
            Save the Segment
          </button>
          <button
            style={{
              color: "red",
              padding: "10px 20px",
              marginLeft: "15px",
              borderRadius: "6px",
              backgroundColor : 'white',
              cursor : 'pointer',
              outline: 0,
              border: 0,
            }}
            onClick={() => {
              setShowSideBar(false);
            }}
          >
            Cancel
          </button>
        </div>
      </div>
    </>
  );
};

export default AddSegment;
