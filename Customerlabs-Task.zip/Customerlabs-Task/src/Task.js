// import React, { useState } from "react";
// import "./Task.css";
// import { fetchApi } from "./service/fetchAPI";

// function Header() {
//   return (
//     <div className="">
//     </div>
//   );
// }

// function Footer({ onSave, onCancel }) {
//   return (
//     
//   );
// }

// function App() {


//   return (
//     <div className="container">
//       <Header />

//       <div className="segment">
//         <h3>Enter the name of the segment</h3>
//         <input
//           type="text"
//           placeholder="Segment Name"
//           value={segmentName}
//           onChange={handleSegmentNameChange}
//         />
//       </div>

//       <div className="schema">
//         <p className="instruction">
//           To save your segment, you need to add the schemas to build the query
//         </p>

//         <div className="schema-buttons">
//           {dropdownButtons.map((button) => (
//             <div key={button.index}>
//               <select
//                 value={button.value}
//                 onChange={(e) => {
//                   const updatedButtons = dropdownButtons.map((b) => {
//                     if (b.index === button.index) {
//                       return { ...b, value: e.target.value };
//                     }
//                     return b;
//                   });
//                   setDropdownButtons(updatedButtons);
//                 }}
//               >
//                 <option value={button.value}>{button.value}</option>
//                 <Task arr={schemas} buttons={dropdownButtons} />
//               </select>
//               <button onClick={() => handleCancelSchema(button.index)}>
//                 X
//               </button>
//             </div>
//           ))}
//         </div>

//         <button className="add-schema-button" onClick={handleAddSchema}>
//           + Add new schema
//         </button>
//       </div>

//       <Footer onSave={finalSubmit} onCancel={handleCancel} />
//     </div>
//   );
// }

// function Task({ arr, buttons }) {
//   const btn = buttons.map((button) => button.value);
//   const list = arr.filter((schema) => !btn.includes(schema.value));

//   return (
//     <>
//       {list.map((schema) => (
//         <option key={schema.value} value={schema.value}>
//           {schema.label}
//         </option>
//       ))}
//     </>
//   );
// }

// export default App;
