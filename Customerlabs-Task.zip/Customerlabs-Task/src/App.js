import React from 'react'; 
import './App.css';
import Task from './Task.js'
import Modal from './Modal.js'
import SideDrawer from './components/SideDrawer.jsx';

function App() {
  return (
    <div className="App">
       {/* <Modal /> */}
       <SideDrawer  />
    </div>
  );
}

export default App;
