export const fetchApi = async (data) => {
  try {
    let response = await fetch(
      "https://webhook.site/581b8250-b205-48c6-b8ca-c9db444c9885",
      {
        method: "POST",
        mode: "no-cors",
        headers: {
          "content-type": "application/json",
        },
        body: JSON.stringify(data),
        responseType: "json",
      }
    );
    alert("Segment saved successfully!");
    return response;
  
  } catch (error) {
    alert(error.message)
  }
};
